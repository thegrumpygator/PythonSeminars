README

This module defines hard-coded values for E and PI.

It also includes computational methods for calculating them as well.

Created: 2016-07-20
Author: vestuto
