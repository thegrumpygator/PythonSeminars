from setuptools import setup
setup(
    name='constants',
    version='0.0.1',
    license='CC BY-NC-SA 4.0',
    long_description=open('README.txt').read(),
    py_modules=['constants',],
    )

