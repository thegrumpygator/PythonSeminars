from numpy.testing import *
import numpy
numpy.random.seed(0)

from algopy import UTPM, Function
from algopy.special import *

class Test_NumpyOperators(TestCase):

    # here should be tests for functions like
    # z = x + y
    # z = x * y
    pass


if __name__ == "__main__":
    run_module_suite()



