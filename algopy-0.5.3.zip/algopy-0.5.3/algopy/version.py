
# THIS FILE IS GENERATED FROM ALGOPY SETUP.PY
short_version='0.5.3'
version='0.5.3'
release=True

if not release:
    version += '.dev2386d237891ea5761845029601b0fe35ff4c8fd6'
