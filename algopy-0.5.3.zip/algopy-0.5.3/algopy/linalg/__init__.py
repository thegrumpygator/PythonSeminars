"""

This module implements functionality
to apply algopy to numpy.linalg and scipy.linalg functions.

"""

from .linalg import *
from .compound import *


